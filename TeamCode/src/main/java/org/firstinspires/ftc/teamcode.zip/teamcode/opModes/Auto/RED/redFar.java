package org.firstinspires.ftc.teamcode.opModes.Auto.RED;

import static org.firstinspires.ftc.teamcode.subsystems.DriveTrain2.closeStopperPos;
import static org.firstinspires.ftc.teamcode.subsystems.DriveTrain2.openStopperPos;
import static org.firstinspires.ftc.teamcode.subsystems.DriveTrain2.servoOffset;
import static org.firstinspires.ftc.teamcode.subsystems.ShooterCalcAccelClaude.calculateShotVectorandUpdateHeading;
import static org.firstinspires.ftc.teamcode.subsystems.Flywheel.shooter;

import com.bylazar.configurables.annotations.Configurable;
import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierCurve;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.math.Vector;
import com.pedropathing.paths.PathChain;
import com.pedropathing.util.Timer;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.hardware.ServoImplEx;

import org.firstinspires.ftc.teamcode.pedroPathing.Constants;
import org.firstinspires.ftc.teamcode.subsystems.Storage;

import java.util.List;

import dev.nextftc.core.commands.Command;
import dev.nextftc.core.commands.delays.Delay;
import dev.nextftc.core.commands.groups.SequentialGroup;
import dev.nextftc.core.commands.utility.LambdaCommand;
import dev.nextftc.core.components.BindingsComponent;
import dev.nextftc.extensions.pedro.FollowPath;
import dev.nextftc.extensions.pedro.PedroComponent;
import dev.nextftc.ftc.ActiveOpMode;
import dev.nextftc.ftc.NextFTCOpMode;
import dev.nextftc.ftc.components.BulkReadComponent;
import dev.nextftc.hardware.impl.MotorEx;
import dev.nextftc.hardware.impl.ServoEx;


@Autonomous(name = "Red Far V14")
@Configurable
public class redFar extends NextFTCOpMode {

    public redFar() {
        addComponents(
                BulkReadComponent.INSTANCE,
                BindingsComponent.INSTANCE,
                new PedroComponent(hwMap -> Constants.createFollower(hwMap))
        );
    }

    private Follower follower;
    private MotorEx transfer;
    private Timer opmodeTimer;
    private Paths paths;

    // Red-alliance start pose, mirrored from blueFar's start pose (42, 9, 90deg)
    // using the same reflection Pose.mirror() applies: x' = 144 - x, y' = y,
    // heading' = normalize(180deg - heading).
    public static double startX = 102;
    public static double startY = 9;

    public Pose start = new Pose(startX, startY, Math.toRadians(90));

    // --- Turret tracking ---
    private ServoEx servoStopper;
    private ServoEx hoodServo;

    // Goal position mirrored from blueFar's (goalX=2, goalY=140) -> (144-2, 140).
    double goalY = 140;
    double goalX = 140.5;

    private static final double MIN_ANGLE = -224.75;
    private static final double MAX_ANGLE = 224.75;
    private static final double TURRET_RANGE = 449.51;
    private double slewedTurretAngle = Double.NaN;
    private double lastChosenTurretAngle = Double.NaN;
    private boolean wrapping = false;
    private final com.qualcomm.robotcore.util.ElapsedTime slewTimer = new com.qualcomm.robotcore.util.ElapsedTime();
    private double lastAppliedOffset = Double.NaN;

    public static double wrapServoOffset = 0.0;
    public static double turretServoThreshold = 0.0002;
    public static double maxSlewNormalDegPerSec = 400;
    public static double maxSlewWrapDegPerSec = 540;
    public static double yawFeedforwardGain = 0.145;

    private double lastServoPos = -1; // was a local var — needs to persist across loops

    private double currentTurretPos = 90;

    private boolean matchStarted = false;
    private boolean useAutoGoalTracking = true;

    private boolean isOverridden = false;
    private double overriddenTurretAngle;

    private MotorEx intakeMotor;
    private ServoImplEx turret1;
    private ServoImplEx turret2;

    public static double turretOffset = 1;
    public static double turretOffset2 = 0;
    public static double turretOffsetStep = -5;

    // Inches from the Pinpoint/Pedro robot pose origin to the turret pivot.
    // Physical robot geometry constant - not alliance/field dependent, unchanged from blueFar.
    public static double turretForwardOffset = -0.52588;
    public static double turretStrafeOffset = 0;

    private Command intakeMotorOn = new LambdaCommand()
            .setStart(() -> {
                intakeMotor.setPower(1);
                transfer.setPower(1);
            });
    private Command farTransfer = new LambdaCommand()
            .setStart(() -> {
                intakeMotor.setPower(0.8);
                transfer.setPower(0.8);
            });

    private Command intakeMotorOff = new LambdaCommand()
            .setStart(() -> {
                intakeMotor.setPower(0);
                transfer.setPower(0);
            });

    private List<LynxModule> allHubs;
    public Pose currPose;

    public double getClosestValidTurretAngle(double relativeGoalDegrees) {
        double base = normalizeDegrees(relativeGoalDegrees);
        double current = Double.isNaN(lastChosenTurretAngle) ? 0.0 : lastChosenTurretAngle;

        double best = Double.NaN;
        double bestCost = Double.MAX_VALUE;
        for (int k = -1; k <= 1; k++) {
            double cand = base + 360.0 * k;
            if (cand < MIN_ANGLE || cand > MAX_ANGLE) continue;
            double cost = Math.abs(cand - current);
            if (cost < bestCost) {
                bestCost = cost;
                best = cand;
            }
        }
        if (Double.isNaN(best)) {
            wrapping = false;
            lastChosenTurretAngle = Math.max(MIN_ANGLE, Math.min(MAX_ANGLE, base));
            return lastChosenTurretAngle;
        }

        double physical = Double.isNaN(slewedTurretAngle) ? 0.0 : slewedTurretAngle;
        wrapping = Math.abs(best - physical) > 90.0;
        lastChosenTurretAngle = best;
        return best;
    }
    private double slewTurret(double target) {
        double elapsedSec = slewTimer.seconds();
        slewTimer.reset();
        if (elapsedSec <= 0 || elapsedSec > 0.5) elapsedSec = 0.02;

        if (Double.isNaN(slewedTurretAngle)) slewedTurretAngle = target;

        double rate = wrapping ? maxSlewWrapDegPerSec : maxSlewNormalDegPerSec;
        double maxDelta = rate * elapsedSec;
        slewedTurretAngle += com.qualcomm.robotcore.util.Range.clip(target - slewedTurretAngle, -maxDelta, maxDelta);
        return slewedTurretAngle;
    }

    private double normalizeDegrees(double degrees) {
        return Math.IEEEremainder(degrees, 360.0);
    }

    private Pose getTurretPose(Pose robotPose) {
        double heading = robotPose.getHeading();

        double cos = Math.cos(heading);
        double sin = Math.sin(heading);

        double turretX = robotPose.getX()
                + turretForwardOffset * cos
                - turretStrafeOffset * sin;

        double turretY = robotPose.getY()
                + turretForwardOffset * sin
                + turretStrafeOffset * cos;

        return new Pose(turretX, turretY, heading);
    }

    private Vector getTurretToGoalVector(Pose turretPose) {
        return new Vector(
                turretPose.distanceFrom(new Pose(goalX, goalY)),
                Math.atan2(goalY - turretPose.getY(), goalX - turretPose.getX())
        );
    }

    double targetTurretAngle;

    public boolean manualTPS = true;

    // --- Custom Override Tracking Commands ---
    public Command setTurretHeading(double degrees) {
        return new LambdaCommand("Set Turret Heading: " + degrees)
                .setStart(() -> {
                    isOverridden = true;
                    overriddenTurretAngle = getClosestValidTurretAngle(degrees);
                })
                .setIsDone(() -> true);
    }


    // ----------------------

    @Override
    public void onInit() {

        allHubs = ActiveOpMode.hardwareMap().getAll(LynxModule.class);

        for (LynxModule hub : allHubs) {
            hub.setBulkCachingMode(LynxModule.BulkCachingMode.MANUAL);
        }

        follower = PedroComponent.follower();

        follower.setStartingPose(start);

        paths = new Paths(follower);

        opmodeTimer = new Timer();

        intakeMotor = new MotorEx("intakeMotor");
        transfer = new MotorEx("transferMotor");

        turret1 = ActiveOpMode.hardwareMap().get(
                ServoImplEx.class,
                "turretServo1");

        turret2 = ActiveOpMode.hardwareMap().get(
                ServoImplEx.class,
                "turretServo2");

        turret1.setPwmRange(new PwmControl.PwmRange(500, 2500));
        turret2.setPwmRange(new PwmControl.PwmRange(500, 2500));
        hoodServo = new ServoEx("hoodServo");

        servoStopper = new ServoEx("stopperServo");

        isOverridden = true;
        preload = true;

        overriddenTurretAngle = getClosestValidTurretAngle(-20);
        double hoodAngle = 0.2;
        hoodServo.setPosition(hoodAngle);
        servoStopper.setPosition(closeStopperPos);
        double robotAngularVelocityRads = follower.getAngularVelocity();
        double robotAngularVelocityDegs = Math.toDegrees(robotAngularVelocityRads);
        double feedforwardOffset = 0;

        targetTurretAngle = getClosestValidTurretAngle(overriddenTurretAngle + turretOffset - feedforwardOffset);
        double servoPositionSignal = 0.05 + ((targetTurretAngle - MIN_ANGLE) / 449.51) * 0.90;
        servoPositionSignal = Math.max(0.05, Math.min(0.95, servoPositionSignal));

        turret1.setPosition(servoPositionSignal + servoOffset);
        turret2.setPosition(servoPositionSignal - servoOffset);
        lastServoPos = servoPositionSignal;



        currentTurretPos = targetTurretAngle;

        telemetry.addLine("Initialized");
        telemetry.update();
    }

    public Command closeStopper = new LambdaCommand()
            .setStart(() -> {
                servoStopper.setPosition(closeStopperPos);
            }).setIsDone(() -> true);


    public Command openStopper = new LambdaCommand()
            .setStart(() -> {
                servoStopper.setPosition(openStopperPos);
            }).setIsDone(() -> true);

    public Command enableGoalTracking() {
        return new LambdaCommand("Enable Goal Tracking")
                .setStart(() -> {
                    isOverridden = false;
                })
                .setIsDone(() -> true);
    }
    private SequentialGroup shoot = new SequentialGroup(
            new Delay(0.3),
            openStopper,
            farTransfer,
            new Delay(0.4),
            intakeMotorOff,
            closeStopper);



    public Command Auto() {
        return new SequentialGroup(
                disablePreload,
                new Delay(1.3),
                shoot,
                intakeMotorOn,
                // --- Spike 1 cycle ---
                new FollowPath(paths.intakeSpike1, true, 1.0),
                new Delay(0.3),
                new FollowPath(paths.shootSpike1, true, 1.0),
                shoot,
                intakeMotorOn,
                // --- Spike 2 cycle ---
                new FollowPath(paths.intakeSpike2, true, 1.0),
                new Delay(0.3),
                new FollowPath(paths.shootSpike2, true, 1.0),
                shoot,
                intakeMotorOn,
                // --- Sweep cycle 1 ---
                new FollowPath(paths.intakeSweepHP1, true, 1.0),
                new Delay(0.3),
                new FollowPath(paths.sweepAndShoot1, true, 1.0),
                shoot,
                intakeMotorOn,
                // --- Sweep cycle 2 ---
                new FollowPath(paths.intakeSweepHP2, true, 1.0),
                new Delay(0.3),
                new FollowPath(paths.sweepAndShoot2, true, 1.0),
                shoot,
                intakeMotorOn,
                // --- Sweep cycle 3 ---
                new FollowPath(paths.intakeSweepHP3, true, 1.0),
                new Delay(0.3),
                new FollowPath(paths.sweepAndShoot3, true, 1.0),
                shoot,
                intakeMotorOn,
                // --- Sweep cycle 4 ---
                new FollowPath(paths.intakeSweepHP4, true, 1.0),
                new Delay(0.3),
                new FollowPath(paths.sweepAndShoot4, true, 1.0),
                shoot,
//                intakeMotorOn,
//                // --- Sweep cycle 5 ---
//                new FollowPath(paths.intakeSweepHP5, true, 1.0),
//                new Delay(0.3),
//                new FollowPath(paths.sweepAndShoot5, true, 1.0),


                new FollowPath(paths.park, true, 1.0)
        );
    }

    public void onStartButtonPressed() {
        opmodeTimer.resetTimer();
        matchStarted = true;
        Auto().schedule();
    }

    private boolean preload = true;

    public Command disablePreload = new LambdaCommand()
            .setStart(() -> preload = false);
    private double flywheelSpeed;

    @Override
    public void onUpdate() {

        for (LynxModule hub : allHubs) {
            hub.clearBulkCache();
        }

        follower.update();

        Storage.currentPose = follower.getPose();

        if (!matchStarted) return;

        Pose currPose = follower.getPose();

        Pose turretPose = getTurretPose(currPose);

        double robotHeading = follower.getPose().getHeading();

        Vector robotToGoalVector = getTurretToGoalVector(turretPose);

        Double[] results = calculateShotVectorandUpdateHeading(
                robotHeading,
                robotToGoalVector,
                follower.getVelocity().times(1.0), follower.getAcceleration());

        flywheelSpeed = results[0];

        if (preload == true) {
            double hoodAngle = results[1];
            hoodServo.setPosition(hoodAngle);
            shooter((float) -(flywheelSpeed + 30));
            double feedforwardOffset = 0;

            double rawTarget = getClosestValidTurretAngle(overriddenTurretAngle - turretOffset - feedforwardOffset);
            targetTurretAngle = slewTurret(rawTarget);

            double servoPositionSignal = 0.05 + ((targetTurretAngle - MIN_ANGLE) / 449.51) * 0.90;
            servoPositionSignal = Math.max(0.05, Math.min(0.95, servoPositionSignal));

            double activeOffset = wrapping ? wrapServoOffset : servoOffset;
            boolean offsetChanged = Math.abs(activeOffset - lastAppliedOffset) > 1e-9 || Double.isNaN(lastAppliedOffset);

            if (lastServoPos < 0 || offsetChanged || Math.abs(servoPositionSignal - lastServoPos) > turretServoThreshold) {
                turret1.setPosition(servoPositionSignal + activeOffset);
                turret2.setPosition(servoPositionSignal - activeOffset);
                lastServoPos = servoPositionSignal;
                lastAppliedOffset = activeOffset;
            }

            currentTurretPos = targetTurretAngle;
        }

        if (preload == false) {
            shooter((float) flywheelSpeed);
            double hoodAngle = results[1];
            hoodServo.setPosition(hoodAngle);
            double headingError = results[2];
            double robotAngularVelocityRads = follower.getAngularVelocity();
            double robotAngularVelocityDegs = Math.toDegrees(robotAngularVelocityRads);
            double feedforwardOffset = robotAngularVelocityDegs * yawFeedforwardGain; // was *115

            double rawTarget = getClosestValidTurretAngle(headingError + turretOffset - feedforwardOffset); // sign flipped to + — see note below
            targetTurretAngle = slewTurret(rawTarget);

            double servoPositionSignal = 0.05 + ((targetTurretAngle - MIN_ANGLE) / 449.51) * 0.90;
            servoPositionSignal = Math.max(0.05, Math.min(0.95, servoPositionSignal));

            double activeOffset = wrapping ? wrapServoOffset : servoOffset;
            boolean offsetChanged = Math.abs(activeOffset - lastAppliedOffset) > 1e-9 || Double.isNaN(lastAppliedOffset);

            if (lastServoPos < 0 || offsetChanged || Math.abs(servoPositionSignal - lastServoPos) > turretServoThreshold) {
                turret1.setPosition(servoPositionSignal + activeOffset);
                turret2.setPosition(servoPositionSignal - activeOffset);
                lastServoPos = servoPositionSignal;
                lastAppliedOffset = activeOffset;
            }

            currentTurretPos = targetTurretAngle;
        }
    }

    @Override
    public void onStop() {
        Storage.currentPose = follower.getPose();
        follower.breakFollowing();
    }

    public class Paths {

        public PathChain intakeSpike1;
        public PathChain shootSpike1;
        public PathChain intakeSpike2;
        public PathChain shootSpike2;

        public PathChain intakeSweepHP1;
        public PathChain hpToShoot1;
        public PathChain sweepAndShoot1;

        public PathChain intakeSweepHP2;
        public PathChain hpToShoot2;
        public PathChain sweepAndShoot2;

        public PathChain intakeSweepHP3;
        public PathChain hpToShoot3;
        public PathChain sweepAndShoot3;

        public PathChain intakeSweepHP4;
        public PathChain hpToShoot4;
        public PathChain sweepAndShoot4;

        public PathChain intakeSweepHP5;
        public PathChain hpToShoot5;
        public PathChain sweepAndShoot5;

        public PathChain park;

        // Red-alliance poses, mirrored from blueFar's poses using the same
        // reflection Pose.mirror() applies: x' = 144 - x, y' = y,
        // heading' = normalize(180deg - heading). Two-arg (x, y) poses have no
        // meaningful heading (control points / default 0), so only x is mirrored
        // for those.

        //====Change these only para paths egg=================
        Pose FIRST_SPIKE = new Pose(120, 45, Math.toRadians(90));
        Pose FIRST_SPIKE_CONTROL = new Pose(119, 20.5);
        Pose FIRST_SHOOT = new Pose(98, 14);
        Pose FIRST_SHOOT_CONTROL = new Pose(120.5, 16);
        Pose SECOND_SPIKE = new Pose(134, 12, Math.toRadians(0));
        Pose SECOND_SHOOT = new Pose(97.5, 14);
        Pose SWEEP_1 = new Pose(133.5, 10, Math.toRadians(0));
        Pose SWEEP_2 = new Pose(133, 14.5, Math.toRadians(60));
        Pose SWEEP_2_CONTROL = new Pose(128.3, 11.8);
        Pose SWEEP_3 = new Pose(133, 34.5, Math.toRadians(60));
        Pose SWEEP_SHOOT = new Pose(87.5, 17.5);
        Pose PARK_POSE = new Pose(98.5, 22.5);

        public Paths(Follower follower) {

            intakeSpike1 = follower.pathBuilder()
                    .addPath(new BezierCurve(start, FIRST_SPIKE_CONTROL, FIRST_SPIKE))
                    .setConstantHeadingInterpolation(FIRST_SPIKE.getHeading())
                    .build();

            shootSpike1 = follower.pathBuilder()
                    .addPath(new BezierCurve(FIRST_SPIKE, FIRST_SHOOT_CONTROL, FIRST_SHOOT))
                    .setTangentHeadingInterpolation()
                    .setReversed()
                    .build();

            intakeSpike2 = follower.pathBuilder()
                    .addPath(new BezierLine(FIRST_SHOOT, SECOND_SPIKE))
                    .setConstantHeadingInterpolation(SECOND_SPIKE.getHeading())
                    .build();

            shootSpike2 = follower.pathBuilder()
                    .addPath(new BezierLine(SECOND_SPIKE, SECOND_SHOOT))
                    .setConstantHeadingInterpolation(SECOND_SPIKE.getHeading())
                    .addTemporalCallback(150, intakeMotorOff)
                    .build();

            //js goon cycle sweep
            intakeSweepHP1 = buildIntakeSweepHP(follower);
            hpToShoot1 = buildHpToShoot(follower);
            sweepAndShoot1 = buildSweepAndShoot(follower);

            intakeSweepHP2 = buildIntakeSweepHP(follower);
            hpToShoot2 = buildHpToShoot(follower);
            sweepAndShoot2 = buildSweepAndShoot(follower);

            intakeSweepHP3 = buildIntakeSweepHP(follower);
            hpToShoot3 = buildHpToShoot(follower);
            sweepAndShoot3 = buildSweepAndShoot(follower);

            intakeSweepHP4 = buildIntakeSweepHP(follower);
            hpToShoot4 = buildHpToShoot(follower);
            sweepAndShoot4 = buildSweepAndShoot(follower);

            intakeSweepHP5 = buildIntakeSweepHP(follower);
            hpToShoot5 = buildHpToShoot(follower);
            sweepAndShoot5 = buildSweepAndShoot(follower);

            park = follower.pathBuilder()
                    .addPath(new BezierLine(SWEEP_SHOOT, PARK_POSE))
                    .setTangentHeadingInterpolation()
                    .build();
        }

        private PathChain buildIntakeSweepHP(Follower follower) {
            return follower.pathBuilder()
                    .addPath(new BezierLine(SECOND_SHOOT, SWEEP_1))
                    .setConstantHeadingInterpolation(SECOND_SPIKE.getHeading())
                    .build();
        }

        private PathChain buildHpToShoot(Follower follower) {
            return follower.pathBuilder()
                    .addPath(new BezierLine(SWEEP_1, SECOND_SHOOT))
                    .setConstantHeadingInterpolation(SECOND_SPIKE.getHeading())
                    .addTemporalCallback(150, intakeMotorOff)
                    .build();
        }

        private PathChain buildSweepAndShoot(Follower follower) {
            return follower.pathBuilder()
                    .addPath(new BezierCurve(SWEEP_1, SWEEP_2_CONTROL, SWEEP_2))
                    .setLinearHeadingInterpolation(SWEEP_1.getHeading(), SWEEP_2.getHeading())
                    .addPath(new BezierLine(SWEEP_2, SWEEP_3))
                    .setConstantHeadingInterpolation(SWEEP_2.getHeading())
                    .addTemporalCallback(150, intakeMotorOff)
                    .addPath(new BezierLine(SWEEP_3, SWEEP_SHOOT))
                    .setBrakingStrength(0.9)
                    .setTangentHeadingInterpolation()
                    .setReversed()
                    .build();
        }
    }
}